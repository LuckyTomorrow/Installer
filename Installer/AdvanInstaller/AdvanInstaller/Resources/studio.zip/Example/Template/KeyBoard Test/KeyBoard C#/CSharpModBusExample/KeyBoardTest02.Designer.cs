﻿namespace MSTest
{
    partial class KeyBoardTest02
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(KeyBoardTest02));
            this.txt_z_dpos = new System.Windows.Forms.TextBox();
            this.txt_x_dpos = new System.Windows.Forms.TextBox();
            this.groupBox3 = new System.Windows.Forms.GroupBox();
            this.btn_jog_neg = new System.Windows.Forms.Button();
            this.btn_jog_pos = new System.Windows.Forms.Button();
            this.radioButton3 = new System.Windows.Forms.RadioButton();
            this.radioButton2 = new System.Windows.Forms.RadioButton();
            this.radioButton1 = new System.Windows.Forms.RadioButton();
            this.txt_state = new System.Windows.Forms.TextBox();
            this.label16 = new System.Windows.Forms.Label();
            this.txt_9_z = new System.Windows.Forms.TextBox();
            this.txt_8_z = new System.Windows.Forms.TextBox();
            this.txt_7_z = new System.Windows.Forms.TextBox();
            this.txt_6_z = new System.Windows.Forms.TextBox();
            this.txt_5_z = new System.Windows.Forms.TextBox();
            this.txt_4_z = new System.Windows.Forms.TextBox();
            this.txt_3_z = new System.Windows.Forms.TextBox();
            this.txt_2_z = new System.Windows.Forms.TextBox();
            this.txt_1_z = new System.Windows.Forms.TextBox();
            this.txt_0_z = new System.Windows.Forms.TextBox();
            this.txt_9_y = new System.Windows.Forms.TextBox();
            this.txt_8_y = new System.Windows.Forms.TextBox();
            this.txt_6_y = new System.Windows.Forms.TextBox();
            this.txt_5_y = new System.Windows.Forms.TextBox();
            this.txt_y_dpos = new System.Windows.Forms.TextBox();
            this.txt_7_y = new System.Windows.Forms.TextBox();
            this.txt_4_y = new System.Windows.Forms.TextBox();
            this.txt_3_y = new System.Windows.Forms.TextBox();
            this.txt_2_y = new System.Windows.Forms.TextBox();
            this.txt_1_y = new System.Windows.Forms.TextBox();
            this.txt_0_y = new System.Windows.Forms.TextBox();
            this.txt_9_x = new System.Windows.Forms.TextBox();
            this.label11 = new System.Windows.Forms.Label();
            this.label13 = new System.Windows.Forms.Label();
            this.label14 = new System.Windows.Forms.Label();
            this.txt_8_x = new System.Windows.Forms.TextBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.label12 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.txt_7_x = new System.Windows.Forms.TextBox();
            this.label9 = new System.Windows.Forms.Label();
            this.txt_6_x = new System.Windows.Forms.TextBox();
            this.label8 = new System.Windows.Forms.Label();
            this.txt_5_x = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.txt_4_x = new System.Windows.Forms.TextBox();
            this.btn_9 = new System.Windows.Forms.Button();
            this.label6 = new System.Windows.Forms.Label();
            this.btn_return = new System.Windows.Forms.Button();
            this.label18 = new System.Windows.Forms.Label();
            this.btn_8 = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.txt_3_x = new System.Windows.Forms.TextBox();
            this.btn_7 = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.btn_6 = new System.Windows.Forms.Button();
            this.txt_2_x = new System.Windows.Forms.TextBox();
            this.btn_5 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.btn_4 = new System.Windows.Forms.Button();
            this.txt_1_x = new System.Windows.Forms.TextBox();
            this.btn_3 = new System.Windows.Forms.Button();
            this.label3 = new System.Windows.Forms.Label();
            this.btn_2 = new System.Windows.Forms.Button();
            this.txt_0_x = new System.Windows.Forms.TextBox();
            this.btn_1 = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.btn_0 = new System.Windows.Forms.Button();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.groupBox4 = new System.Windows.Forms.GroupBox();
            this.btn_ptp9 = new System.Windows.Forms.Button();
            this.btn_ptp8 = new System.Windows.Forms.Button();
            this.btn_ptp7 = new System.Windows.Forms.Button();
            this.btn_ptp6 = new System.Windows.Forms.Button();
            this.btn_ptp5 = new System.Windows.Forms.Button();
            this.btn_ptp4 = new System.Windows.Forms.Button();
            this.btn_ptp3 = new System.Windows.Forms.Button();
            this.btn_ptp2 = new System.Windows.Forms.Button();
            this.btn_ptp1 = new System.Windows.Forms.Button();
            this.btn_ptp0 = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.label1 = new System.Windows.Forms.Label();
            this.groupBox3.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.SuspendLayout();
            // 
            // txt_z_dpos
            // 
            this.txt_z_dpos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.txt_z_dpos.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_z_dpos.ForeColor = System.Drawing.Color.Black;
            this.txt_z_dpos.Location = new System.Drawing.Point(219, 63);
            this.txt_z_dpos.Name = "txt_z_dpos";
            this.txt_z_dpos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_z_dpos.Size = new System.Drawing.Size(90, 23);
            this.txt_z_dpos.TabIndex = 5;
            this.txt_z_dpos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_x_dpos
            // 
            this.txt_x_dpos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.txt_x_dpos.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_x_dpos.ForeColor = System.Drawing.Color.Black;
            this.txt_x_dpos.Location = new System.Drawing.Point(27, 63);
            this.txt_x_dpos.Name = "txt_x_dpos";
            this.txt_x_dpos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_x_dpos.Size = new System.Drawing.Size(90, 23);
            this.txt_x_dpos.TabIndex = 6;
            this.txt_x_dpos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // groupBox3
            // 
            this.groupBox3.Controls.Add(this.btn_jog_neg);
            this.groupBox3.Controls.Add(this.btn_jog_pos);
            this.groupBox3.Controls.Add(this.radioButton3);
            this.groupBox3.Controls.Add(this.radioButton2);
            this.groupBox3.Controls.Add(this.radioButton1);
            this.groupBox3.Controls.Add(this.txt_state);
            this.groupBox3.Controls.Add(this.label16);
            this.groupBox3.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox3.ForeColor = System.Drawing.Color.Cyan;
            this.groupBox3.Location = new System.Drawing.Point(385, 218);
            this.groupBox3.Name = "groupBox3";
            this.groupBox3.Size = new System.Drawing.Size(336, 147);
            this.groupBox3.TabIndex = 16;
            this.groupBox3.TabStop = false;
            this.groupBox3.Text = "JOG Operation";
            // 
            // btn_jog_neg
            // 
            this.btn_jog_neg.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_jog_neg.ForeColor = System.Drawing.Color.Black;
            this.btn_jog_neg.Location = new System.Drawing.Point(101, 90);
            this.btn_jog_neg.Name = "btn_jog_neg";
            this.btn_jog_neg.Size = new System.Drawing.Size(75, 38);
            this.btn_jog_neg.TabIndex = 12;
            this.btn_jog_neg.Text = "JOG-";
            this.btn_jog_neg.UseVisualStyleBackColor = false;
            this.btn_jog_neg.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btn_jog_neg_MouseDown);
            this.btn_jog_neg.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_jog_neg_MouseUp);
            // 
            // btn_jog_pos
            // 
            this.btn_jog_pos.BackColor = System.Drawing.Color.DarkOrange;
            this.btn_jog_pos.ForeColor = System.Drawing.Color.Black;
            this.btn_jog_pos.Location = new System.Drawing.Point(219, 90);
            this.btn_jog_pos.Name = "btn_jog_pos";
            this.btn_jog_pos.Size = new System.Drawing.Size(75, 38);
            this.btn_jog_pos.TabIndex = 12;
            this.btn_jog_pos.Text = "JOG+";
            this.btn_jog_pos.UseVisualStyleBackColor = false;
            this.btn_jog_pos.Click += new System.EventHandler(this.btn_jog_pos_Click);
            this.btn_jog_pos.MouseDown += new System.Windows.Forms.MouseEventHandler(this.btn_jog_pos_MouseDown);
            this.btn_jog_pos.MouseUp += new System.Windows.Forms.MouseEventHandler(this.btn_jog_pos_MouseUp);
            // 
            // radioButton3
            // 
            this.radioButton3.AutoSize = true;
            this.radioButton3.ForeColor = System.Drawing.Color.Black;
            this.radioButton3.Location = new System.Drawing.Point(224, 29);
            this.radioButton3.Name = "radioButton3";
            this.radioButton3.Size = new System.Drawing.Size(70, 23);
            this.radioButton3.TabIndex = 11;
            this.radioButton3.Text = "Z Axis";
            this.radioButton3.UseVisualStyleBackColor = true;
            this.radioButton3.CheckedChanged += new System.EventHandler(this.radioButton3_CheckedChanged);
            // 
            // radioButton2
            // 
            this.radioButton2.AutoSize = true;
            this.radioButton2.ForeColor = System.Drawing.Color.Black;
            this.radioButton2.Location = new System.Drawing.Point(144, 29);
            this.radioButton2.Name = "radioButton2";
            this.radioButton2.Size = new System.Drawing.Size(70, 23);
            this.radioButton2.TabIndex = 11;
            this.radioButton2.Text = "Y Axis";
            this.radioButton2.UseVisualStyleBackColor = true;
            this.radioButton2.CheckedChanged += new System.EventHandler(this.radioButton2_CheckedChanged);
            // 
            // radioButton1
            // 
            this.radioButton1.AutoSize = true;
            this.radioButton1.Checked = true;
            this.radioButton1.ForeColor = System.Drawing.Color.Black;
            this.radioButton1.Location = new System.Drawing.Point(67, 29);
            this.radioButton1.Name = "radioButton1";
            this.radioButton1.Size = new System.Drawing.Size(71, 23);
            this.radioButton1.TabIndex = 11;
            this.radioButton1.TabStop = true;
            this.radioButton1.Text = "X Axis";
            this.radioButton1.UseVisualStyleBackColor = true;
            this.radioButton1.CheckedChanged += new System.EventHandler(this.radioButton1_CheckedChanged);
            // 
            // txt_state
            // 
            this.txt_state.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.txt_state.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_state.ForeColor = System.Drawing.Color.Black;
            this.txt_state.Location = new System.Drawing.Point(101, 59);
            this.txt_state.Name = "txt_state";
            this.txt_state.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.txt_state.Size = new System.Drawing.Size(193, 23);
            this.txt_state.TabIndex = 6;
            this.txt_state.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // label16
            // 
            this.label16.AutoSize = true;
            this.label16.Font = new System.Drawing.Font("微软雅黑", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label16.ForeColor = System.Drawing.Color.Black;
            this.label16.Location = new System.Drawing.Point(6, 59);
            this.label16.Name = "label16";
            this.label16.Size = new System.Drawing.Size(91, 22);
            this.label16.TabIndex = 9;
            this.label16.Text = "Axis State";
            // 
            // txt_9_z
            // 
            this.txt_9_z.BackColor = System.Drawing.Color.Black;
            this.txt_9_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_9_z.ForeColor = System.Drawing.Color.White;
            this.txt_9_z.Location = new System.Drawing.Point(219, 299);
            this.txt_9_z.Name = "txt_9_z";
            this.txt_9_z.Size = new System.Drawing.Size(72, 23);
            this.txt_9_z.TabIndex = 8;
            this.txt_9_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_9_z.Validated += new System.EventHandler(this.txt_9_z_Validated);
            // 
            // txt_8_z
            // 
            this.txt_8_z.BackColor = System.Drawing.Color.Black;
            this.txt_8_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_8_z.ForeColor = System.Drawing.Color.White;
            this.txt_8_z.Location = new System.Drawing.Point(219, 270);
            this.txt_8_z.Name = "txt_8_z";
            this.txt_8_z.Size = new System.Drawing.Size(72, 23);
            this.txt_8_z.TabIndex = 8;
            this.txt_8_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_8_z.Validated += new System.EventHandler(this.txt_8_z_Validated);
            // 
            // txt_7_z
            // 
            this.txt_7_z.BackColor = System.Drawing.Color.Black;
            this.txt_7_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_7_z.ForeColor = System.Drawing.Color.White;
            this.txt_7_z.Location = new System.Drawing.Point(219, 241);
            this.txt_7_z.Name = "txt_7_z";
            this.txt_7_z.Size = new System.Drawing.Size(72, 23);
            this.txt_7_z.TabIndex = 8;
            this.txt_7_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_7_z.Validated += new System.EventHandler(this.txt_7_z_Validated);
            // 
            // txt_6_z
            // 
            this.txt_6_z.BackColor = System.Drawing.Color.Black;
            this.txt_6_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_6_z.ForeColor = System.Drawing.Color.White;
            this.txt_6_z.Location = new System.Drawing.Point(219, 212);
            this.txt_6_z.Name = "txt_6_z";
            this.txt_6_z.Size = new System.Drawing.Size(72, 23);
            this.txt_6_z.TabIndex = 8;
            this.txt_6_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_6_z.Validated += new System.EventHandler(this.txt_6_z_Validated);
            // 
            // txt_5_z
            // 
            this.txt_5_z.BackColor = System.Drawing.Color.Black;
            this.txt_5_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_5_z.ForeColor = System.Drawing.Color.White;
            this.txt_5_z.Location = new System.Drawing.Point(219, 183);
            this.txt_5_z.Name = "txt_5_z";
            this.txt_5_z.Size = new System.Drawing.Size(72, 23);
            this.txt_5_z.TabIndex = 8;
            this.txt_5_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_5_z.Validated += new System.EventHandler(this.txt_5_z_Validated);
            // 
            // txt_4_z
            // 
            this.txt_4_z.BackColor = System.Drawing.Color.Black;
            this.txt_4_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_4_z.ForeColor = System.Drawing.Color.White;
            this.txt_4_z.Location = new System.Drawing.Point(219, 154);
            this.txt_4_z.Name = "txt_4_z";
            this.txt_4_z.Size = new System.Drawing.Size(72, 23);
            this.txt_4_z.TabIndex = 8;
            this.txt_4_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_4_z.Validated += new System.EventHandler(this.txt_4_z_Validated);
            // 
            // txt_3_z
            // 
            this.txt_3_z.BackColor = System.Drawing.Color.Black;
            this.txt_3_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_3_z.ForeColor = System.Drawing.Color.White;
            this.txt_3_z.Location = new System.Drawing.Point(219, 125);
            this.txt_3_z.Name = "txt_3_z";
            this.txt_3_z.Size = new System.Drawing.Size(72, 23);
            this.txt_3_z.TabIndex = 8;
            this.txt_3_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_3_z.Validated += new System.EventHandler(this.txt_3_z_Validated);
            // 
            // txt_2_z
            // 
            this.txt_2_z.BackColor = System.Drawing.Color.Black;
            this.txt_2_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_2_z.ForeColor = System.Drawing.Color.White;
            this.txt_2_z.Location = new System.Drawing.Point(219, 96);
            this.txt_2_z.Name = "txt_2_z";
            this.txt_2_z.Size = new System.Drawing.Size(72, 23);
            this.txt_2_z.TabIndex = 8;
            this.txt_2_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_2_z.Validated += new System.EventHandler(this.txt_2_z_Validated);
            // 
            // txt_1_z
            // 
            this.txt_1_z.BackColor = System.Drawing.Color.Black;
            this.txt_1_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_1_z.ForeColor = System.Drawing.Color.White;
            this.txt_1_z.Location = new System.Drawing.Point(219, 67);
            this.txt_1_z.Name = "txt_1_z";
            this.txt_1_z.Size = new System.Drawing.Size(72, 23);
            this.txt_1_z.TabIndex = 8;
            this.txt_1_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_1_z.Validated += new System.EventHandler(this.txt_1_z_Validated);
            // 
            // txt_0_z
            // 
            this.txt_0_z.BackColor = System.Drawing.Color.Black;
            this.txt_0_z.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_0_z.ForeColor = System.Drawing.Color.White;
            this.txt_0_z.Location = new System.Drawing.Point(219, 38);
            this.txt_0_z.Name = "txt_0_z";
            this.txt_0_z.Size = new System.Drawing.Size(72, 23);
            this.txt_0_z.TabIndex = 8;
            this.txt_0_z.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_0_z.Validated += new System.EventHandler(this.txt_0_z_Validated);
            // 
            // txt_9_y
            // 
            this.txt_9_y.BackColor = System.Drawing.Color.Black;
            this.txt_9_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_9_y.ForeColor = System.Drawing.Color.White;
            this.txt_9_y.Location = new System.Drawing.Point(141, 298);
            this.txt_9_y.Name = "txt_9_y";
            this.txt_9_y.Size = new System.Drawing.Size(72, 23);
            this.txt_9_y.TabIndex = 8;
            this.txt_9_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_9_y.Validated += new System.EventHandler(this.txt_9_y_Validated);
            // 
            // txt_8_y
            // 
            this.txt_8_y.BackColor = System.Drawing.Color.Black;
            this.txt_8_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_8_y.ForeColor = System.Drawing.Color.White;
            this.txt_8_y.Location = new System.Drawing.Point(141, 269);
            this.txt_8_y.Name = "txt_8_y";
            this.txt_8_y.Size = new System.Drawing.Size(72, 23);
            this.txt_8_y.TabIndex = 8;
            this.txt_8_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_8_y.Validated += new System.EventHandler(this.txt_8_y_Validated);
            // 
            // txt_6_y
            // 
            this.txt_6_y.BackColor = System.Drawing.Color.Black;
            this.txt_6_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_6_y.ForeColor = System.Drawing.Color.White;
            this.txt_6_y.Location = new System.Drawing.Point(141, 211);
            this.txt_6_y.Name = "txt_6_y";
            this.txt_6_y.Size = new System.Drawing.Size(72, 23);
            this.txt_6_y.TabIndex = 8;
            this.txt_6_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_6_y.Validated += new System.EventHandler(this.txt_6_y_Validated);
            // 
            // txt_5_y
            // 
            this.txt_5_y.BackColor = System.Drawing.Color.Black;
            this.txt_5_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_5_y.ForeColor = System.Drawing.Color.White;
            this.txt_5_y.Location = new System.Drawing.Point(141, 182);
            this.txt_5_y.Name = "txt_5_y";
            this.txt_5_y.Size = new System.Drawing.Size(72, 23);
            this.txt_5_y.TabIndex = 8;
            this.txt_5_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_5_y.Validated += new System.EventHandler(this.txt_5_y_Validated);
            // 
            // txt_y_dpos
            // 
            this.txt_y_dpos.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.txt_y_dpos.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_y_dpos.ForeColor = System.Drawing.Color.Black;
            this.txt_y_dpos.Location = new System.Drawing.Point(123, 63);
            this.txt_y_dpos.Name = "txt_y_dpos";
            this.txt_y_dpos.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txt_y_dpos.Size = new System.Drawing.Size(90, 23);
            this.txt_y_dpos.TabIndex = 4;
            this.txt_y_dpos.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // txt_7_y
            // 
            this.txt_7_y.BackColor = System.Drawing.Color.Black;
            this.txt_7_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_7_y.ForeColor = System.Drawing.Color.White;
            this.txt_7_y.Location = new System.Drawing.Point(141, 240);
            this.txt_7_y.Name = "txt_7_y";
            this.txt_7_y.Size = new System.Drawing.Size(72, 23);
            this.txt_7_y.TabIndex = 8;
            this.txt_7_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_7_y.Validated += new System.EventHandler(this.txt_7_y_Validated);
            // 
            // txt_4_y
            // 
            this.txt_4_y.BackColor = System.Drawing.Color.Black;
            this.txt_4_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_4_y.ForeColor = System.Drawing.Color.White;
            this.txt_4_y.Location = new System.Drawing.Point(141, 153);
            this.txt_4_y.Name = "txt_4_y";
            this.txt_4_y.Size = new System.Drawing.Size(72, 23);
            this.txt_4_y.TabIndex = 8;
            this.txt_4_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_4_y.Validated += new System.EventHandler(this.txt_4_y_Validated);
            // 
            // txt_3_y
            // 
            this.txt_3_y.BackColor = System.Drawing.Color.Black;
            this.txt_3_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_3_y.ForeColor = System.Drawing.Color.White;
            this.txt_3_y.Location = new System.Drawing.Point(141, 124);
            this.txt_3_y.Name = "txt_3_y";
            this.txt_3_y.Size = new System.Drawing.Size(72, 23);
            this.txt_3_y.TabIndex = 8;
            this.txt_3_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_3_y.Validated += new System.EventHandler(this.txt_3_y_Validated);
            // 
            // txt_2_y
            // 
            this.txt_2_y.BackColor = System.Drawing.Color.Black;
            this.txt_2_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_2_y.ForeColor = System.Drawing.Color.White;
            this.txt_2_y.Location = new System.Drawing.Point(141, 95);
            this.txt_2_y.Name = "txt_2_y";
            this.txt_2_y.Size = new System.Drawing.Size(72, 23);
            this.txt_2_y.TabIndex = 8;
            this.txt_2_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_2_y.Validated += new System.EventHandler(this.txt_2_y_Validated);
            // 
            // txt_1_y
            // 
            this.txt_1_y.BackColor = System.Drawing.Color.Black;
            this.txt_1_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_1_y.ForeColor = System.Drawing.Color.White;
            this.txt_1_y.Location = new System.Drawing.Point(141, 66);
            this.txt_1_y.Name = "txt_1_y";
            this.txt_1_y.Size = new System.Drawing.Size(72, 23);
            this.txt_1_y.TabIndex = 8;
            this.txt_1_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_1_y.Validated += new System.EventHandler(this.txt_1_y_Validated);
            // 
            // txt_0_y
            // 
            this.txt_0_y.BackColor = System.Drawing.Color.Black;
            this.txt_0_y.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_0_y.ForeColor = System.Drawing.Color.White;
            this.txt_0_y.Location = new System.Drawing.Point(141, 37);
            this.txt_0_y.Name = "txt_0_y";
            this.txt_0_y.Size = new System.Drawing.Size(72, 23);
            this.txt_0_y.TabIndex = 8;
            this.txt_0_y.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_0_y.TextChanged += new System.EventHandler(this.txt_0_y_TextChanged);
            this.txt_0_y.Validated += new System.EventHandler(this.txt_0_y_Validated);
            // 
            // txt_9_x
            // 
            this.txt_9_x.BackColor = System.Drawing.Color.Black;
            this.txt_9_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_9_x.ForeColor = System.Drawing.Color.White;
            this.txt_9_x.Location = new System.Drawing.Point(63, 298);
            this.txt_9_x.Name = "txt_9_x";
            this.txt_9_x.Size = new System.Drawing.Size(72, 23);
            this.txt_9_x.TabIndex = 8;
            this.txt_9_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_9_x.Validated += new System.EventHandler(this.txt_9_x_Validated);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.ForeColor = System.Drawing.Color.Black;
            this.label11.Location = new System.Drawing.Point(7, 299);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(56, 19);
            this.label11.TabIndex = 6;
            this.label11.Text = "Key \'9\'";
            // 
            // label13
            // 
            this.label13.AutoSize = true;
            this.label13.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label13.ForeColor = System.Drawing.Color.Black;
            this.label13.Location = new System.Drawing.Point(162, 35);
            this.label13.Name = "label13";
            this.label13.Size = new System.Drawing.Size(17, 16);
            this.label13.TabIndex = 8;
            this.label13.Text = "Y";
            // 
            // label14
            // 
            this.label14.AutoSize = true;
            this.label14.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label14.ForeColor = System.Drawing.Color.Black;
            this.label14.Location = new System.Drawing.Point(67, 35);
            this.label14.Name = "label14";
            this.label14.Size = new System.Drawing.Size(17, 16);
            this.label14.TabIndex = 9;
            this.label14.Text = "X";
            // 
            // txt_8_x
            // 
            this.txt_8_x.BackColor = System.Drawing.Color.Black;
            this.txt_8_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_8_x.ForeColor = System.Drawing.Color.White;
            this.txt_8_x.Location = new System.Drawing.Point(63, 269);
            this.txt_8_x.Name = "txt_8_x";
            this.txt_8_x.Size = new System.Drawing.Size(72, 23);
            this.txt_8_x.TabIndex = 8;
            this.txt_8_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_8_x.Validated += new System.EventHandler(this.txt_8_x_Validated);
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.label12);
            this.groupBox2.Controls.Add(this.label13);
            this.groupBox2.Controls.Add(this.label14);
            this.groupBox2.Controls.Add(this.txt_z_dpos);
            this.groupBox2.Controls.Add(this.txt_y_dpos);
            this.groupBox2.Controls.Add(this.txt_x_dpos);
            this.groupBox2.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox2.ForeColor = System.Drawing.Color.Cyan;
            this.groupBox2.Location = new System.Drawing.Point(385, 105);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(336, 107);
            this.groupBox2.TabIndex = 17;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Current Position";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("宋体", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label12.ForeColor = System.Drawing.Color.Black;
            this.label12.Location = new System.Drawing.Point(256, 35);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(17, 16);
            this.label12.TabIndex = 7;
            this.label12.Text = "Z";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.ForeColor = System.Drawing.Color.Black;
            this.label10.Location = new System.Drawing.Point(7, 270);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(56, 19);
            this.label10.TabIndex = 6;
            this.label10.Text = "Key \'8\'";
            // 
            // txt_7_x
            // 
            this.txt_7_x.BackColor = System.Drawing.Color.Black;
            this.txt_7_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_7_x.ForeColor = System.Drawing.Color.White;
            this.txt_7_x.Location = new System.Drawing.Point(63, 240);
            this.txt_7_x.Name = "txt_7_x";
            this.txt_7_x.Size = new System.Drawing.Size(72, 23);
            this.txt_7_x.TabIndex = 8;
            this.txt_7_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_7_x.Validated += new System.EventHandler(this.txt_7_x_Validated);
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.ForeColor = System.Drawing.Color.Black;
            this.label9.Location = new System.Drawing.Point(7, 241);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(56, 19);
            this.label9.TabIndex = 6;
            this.label9.Text = "Key \'7\'";
            // 
            // txt_6_x
            // 
            this.txt_6_x.BackColor = System.Drawing.Color.Black;
            this.txt_6_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_6_x.ForeColor = System.Drawing.Color.White;
            this.txt_6_x.Location = new System.Drawing.Point(63, 211);
            this.txt_6_x.Name = "txt_6_x";
            this.txt_6_x.Size = new System.Drawing.Size(72, 23);
            this.txt_6_x.TabIndex = 8;
            this.txt_6_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_6_x.Validated += new System.EventHandler(this.txt_6_x_Validated);
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.ForeColor = System.Drawing.Color.Black;
            this.label8.Location = new System.Drawing.Point(7, 212);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(56, 19);
            this.label8.TabIndex = 6;
            this.label8.Text = "Key \'6\'";
            // 
            // txt_5_x
            // 
            this.txt_5_x.BackColor = System.Drawing.Color.Black;
            this.txt_5_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_5_x.ForeColor = System.Drawing.Color.White;
            this.txt_5_x.Location = new System.Drawing.Point(63, 182);
            this.txt_5_x.Name = "txt_5_x";
            this.txt_5_x.Size = new System.Drawing.Size(72, 23);
            this.txt_5_x.TabIndex = 8;
            this.txt_5_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_5_x.Validated += new System.EventHandler(this.txt_5_x_Validated);
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.ForeColor = System.Drawing.Color.Black;
            this.label7.Location = new System.Drawing.Point(7, 183);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(56, 19);
            this.label7.TabIndex = 6;
            this.label7.Text = "Key \'5\'";
            // 
            // txt_4_x
            // 
            this.txt_4_x.BackColor = System.Drawing.Color.Black;
            this.txt_4_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_4_x.ForeColor = System.Drawing.Color.White;
            this.txt_4_x.Location = new System.Drawing.Point(63, 153);
            this.txt_4_x.Name = "txt_4_x";
            this.txt_4_x.Size = new System.Drawing.Size(72, 23);
            this.txt_4_x.TabIndex = 8;
            this.txt_4_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_4_x.Validated += new System.EventHandler(this.txt_4_x_Validated);
            // 
            // btn_9
            // 
            this.btn_9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_9.ForeColor = System.Drawing.Color.Black;
            this.btn_9.Location = new System.Drawing.Point(297, 298);
            this.btn_9.Name = "btn_9";
            this.btn_9.Size = new System.Drawing.Size(23, 24);
            this.btn_9.TabIndex = 5;
            this.btn_9.UseVisualStyleBackColor = false;
            this.btn_9.Click += new System.EventHandler(this.btn_9_Click);
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.ForeColor = System.Drawing.Color.Black;
            this.label6.Location = new System.Drawing.Point(7, 154);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(56, 19);
            this.label6.TabIndex = 6;
            this.label6.Text = "Key \'4\'";
            // 
            // btn_return
            // 
            this.btn_return.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btn_return.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_return.ForeColor = System.Drawing.Color.Black;
            this.btn_return.Location = new System.Drawing.Point(646, 457);
            this.btn_return.Name = "btn_return";
            this.btn_return.Size = new System.Drawing.Size(75, 38);
            this.btn_return.TabIndex = 19;
            this.btn_return.Text = "Main";
            this.btn_return.UseVisualStyleBackColor = false;
            this.btn_return.Click += new System.EventHandler(this.btn_return_Click);
            // 
            // label18
            // 
            this.label18.AutoSize = true;
            this.label18.Location = new System.Drawing.Point(567, 93);
            this.label18.Name = "label18";
            this.label18.Size = new System.Drawing.Size(0, 12);
            this.label18.TabIndex = 20;
            // 
            // btn_8
            // 
            this.btn_8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_8.ForeColor = System.Drawing.Color.Black;
            this.btn_8.Location = new System.Drawing.Point(297, 269);
            this.btn_8.Name = "btn_8";
            this.btn_8.Size = new System.Drawing.Size(23, 24);
            this.btn_8.TabIndex = 5;
            this.btn_8.UseVisualStyleBackColor = false;
            this.btn_8.Click += new System.EventHandler(this.btn_8_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.txt_9_z);
            this.groupBox1.Controls.Add(this.txt_8_z);
            this.groupBox1.Controls.Add(this.txt_7_z);
            this.groupBox1.Controls.Add(this.txt_6_z);
            this.groupBox1.Controls.Add(this.txt_5_z);
            this.groupBox1.Controls.Add(this.txt_4_z);
            this.groupBox1.Controls.Add(this.txt_3_z);
            this.groupBox1.Controls.Add(this.txt_2_z);
            this.groupBox1.Controls.Add(this.txt_1_z);
            this.groupBox1.Controls.Add(this.txt_0_z);
            this.groupBox1.Controls.Add(this.txt_9_y);
            this.groupBox1.Controls.Add(this.txt_8_y);
            this.groupBox1.Controls.Add(this.txt_7_y);
            this.groupBox1.Controls.Add(this.txt_6_y);
            this.groupBox1.Controls.Add(this.txt_5_y);
            this.groupBox1.Controls.Add(this.txt_4_y);
            this.groupBox1.Controls.Add(this.txt_3_y);
            this.groupBox1.Controls.Add(this.txt_2_y);
            this.groupBox1.Controls.Add(this.txt_1_y);
            this.groupBox1.Controls.Add(this.txt_0_y);
            this.groupBox1.Controls.Add(this.txt_9_x);
            this.groupBox1.Controls.Add(this.label11);
            this.groupBox1.Controls.Add(this.txt_8_x);
            this.groupBox1.Controls.Add(this.label10);
            this.groupBox1.Controls.Add(this.txt_7_x);
            this.groupBox1.Controls.Add(this.label9);
            this.groupBox1.Controls.Add(this.txt_6_x);
            this.groupBox1.Controls.Add(this.label8);
            this.groupBox1.Controls.Add(this.txt_5_x);
            this.groupBox1.Controls.Add(this.label7);
            this.groupBox1.Controls.Add(this.txt_4_x);
            this.groupBox1.Controls.Add(this.btn_9);
            this.groupBox1.Controls.Add(this.label6);
            this.groupBox1.Controls.Add(this.btn_8);
            this.groupBox1.Controls.Add(this.txt_3_x);
            this.groupBox1.Controls.Add(this.btn_7);
            this.groupBox1.Controls.Add(this.label5);
            this.groupBox1.Controls.Add(this.btn_6);
            this.groupBox1.Controls.Add(this.txt_2_x);
            this.groupBox1.Controls.Add(this.btn_5);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.btn_4);
            this.groupBox1.Controls.Add(this.txt_1_x);
            this.groupBox1.Controls.Add(this.btn_3);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Controls.Add(this.btn_2);
            this.groupBox1.Controls.Add(this.txt_0_x);
            this.groupBox1.Controls.Add(this.btn_1);
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.btn_0);
            this.groupBox1.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox1.ForeColor = System.Drawing.Color.Cyan;
            this.groupBox1.Location = new System.Drawing.Point(22, 105);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(336, 346);
            this.groupBox1.TabIndex = 18;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Teach Params";
            // 
            // txt_3_x
            // 
            this.txt_3_x.BackColor = System.Drawing.Color.Black;
            this.txt_3_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_3_x.ForeColor = System.Drawing.Color.White;
            this.txt_3_x.Location = new System.Drawing.Point(63, 124);
            this.txt_3_x.Name = "txt_3_x";
            this.txt_3_x.Size = new System.Drawing.Size(72, 23);
            this.txt_3_x.TabIndex = 8;
            this.txt_3_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_3_x.Validated += new System.EventHandler(this.txt_3_x_Validated);
            // 
            // btn_7
            // 
            this.btn_7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_7.ForeColor = System.Drawing.Color.Black;
            this.btn_7.Location = new System.Drawing.Point(297, 240);
            this.btn_7.Name = "btn_7";
            this.btn_7.Size = new System.Drawing.Size(23, 24);
            this.btn_7.TabIndex = 5;
            this.btn_7.UseVisualStyleBackColor = false;
            this.btn_7.Click += new System.EventHandler(this.btn_7_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.ForeColor = System.Drawing.Color.Black;
            this.label5.Location = new System.Drawing.Point(7, 125);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(56, 19);
            this.label5.TabIndex = 6;
            this.label5.Text = "Key \'3\'";
            // 
            // btn_6
            // 
            this.btn_6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_6.ForeColor = System.Drawing.Color.Black;
            this.btn_6.Location = new System.Drawing.Point(297, 211);
            this.btn_6.Name = "btn_6";
            this.btn_6.Size = new System.Drawing.Size(23, 24);
            this.btn_6.TabIndex = 5;
            this.btn_6.UseVisualStyleBackColor = false;
            this.btn_6.Click += new System.EventHandler(this.btn_6_Click);
            // 
            // txt_2_x
            // 
            this.txt_2_x.BackColor = System.Drawing.Color.Black;
            this.txt_2_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_2_x.ForeColor = System.Drawing.Color.White;
            this.txt_2_x.Location = new System.Drawing.Point(63, 95);
            this.txt_2_x.Name = "txt_2_x";
            this.txt_2_x.Size = new System.Drawing.Size(72, 23);
            this.txt_2_x.TabIndex = 8;
            this.txt_2_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_2_x.Validated += new System.EventHandler(this.txt_2_x_Validated);
            // 
            // btn_5
            // 
            this.btn_5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_5.ForeColor = System.Drawing.Color.Black;
            this.btn_5.Location = new System.Drawing.Point(297, 182);
            this.btn_5.Name = "btn_5";
            this.btn_5.Size = new System.Drawing.Size(23, 24);
            this.btn_5.TabIndex = 5;
            this.btn_5.UseVisualStyleBackColor = false;
            this.btn_5.Click += new System.EventHandler(this.btn_5_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.ForeColor = System.Drawing.Color.Black;
            this.label4.Location = new System.Drawing.Point(7, 96);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 19);
            this.label4.TabIndex = 6;
            this.label4.Text = "Key \'2\'";
            // 
            // btn_4
            // 
            this.btn_4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_4.ForeColor = System.Drawing.Color.Black;
            this.btn_4.Location = new System.Drawing.Point(297, 153);
            this.btn_4.Name = "btn_4";
            this.btn_4.Size = new System.Drawing.Size(23, 24);
            this.btn_4.TabIndex = 5;
            this.btn_4.UseVisualStyleBackColor = false;
            this.btn_4.Click += new System.EventHandler(this.btn_4_Click);
            // 
            // txt_1_x
            // 
            this.txt_1_x.BackColor = System.Drawing.Color.Black;
            this.txt_1_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_1_x.ForeColor = System.Drawing.Color.White;
            this.txt_1_x.Location = new System.Drawing.Point(63, 66);
            this.txt_1_x.Name = "txt_1_x";
            this.txt_1_x.Size = new System.Drawing.Size(72, 23);
            this.txt_1_x.TabIndex = 8;
            this.txt_1_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_1_x.Validated += new System.EventHandler(this.txt_1_x_Validated);
            // 
            // btn_3
            // 
            this.btn_3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_3.ForeColor = System.Drawing.Color.Black;
            this.btn_3.Location = new System.Drawing.Point(297, 124);
            this.btn_3.Name = "btn_3";
            this.btn_3.Size = new System.Drawing.Size(23, 24);
            this.btn_3.TabIndex = 5;
            this.btn_3.UseVisualStyleBackColor = false;
            this.btn_3.Click += new System.EventHandler(this.btn_3_Click);
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.ForeColor = System.Drawing.Color.Black;
            this.label3.Location = new System.Drawing.Point(7, 67);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(56, 19);
            this.label3.TabIndex = 6;
            this.label3.Text = "Key \'1\'";
            // 
            // btn_2
            // 
            this.btn_2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_2.ForeColor = System.Drawing.Color.Black;
            this.btn_2.Location = new System.Drawing.Point(297, 95);
            this.btn_2.Name = "btn_2";
            this.btn_2.Size = new System.Drawing.Size(23, 24);
            this.btn_2.TabIndex = 5;
            this.btn_2.UseVisualStyleBackColor = false;
            this.btn_2.Click += new System.EventHandler(this.btn_2_Click);
            // 
            // txt_0_x
            // 
            this.txt_0_x.BackColor = System.Drawing.Color.Black;
            this.txt_0_x.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.txt_0_x.ForeColor = System.Drawing.Color.White;
            this.txt_0_x.Location = new System.Drawing.Point(63, 37);
            this.txt_0_x.Name = "txt_0_x";
            this.txt_0_x.Size = new System.Drawing.Size(72, 23);
            this.txt_0_x.TabIndex = 8;
            this.txt_0_x.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            this.txt_0_x.Validated += new System.EventHandler(this.txt_0_x_Validated);
            // 
            // btn_1
            // 
            this.btn_1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_1.ForeColor = System.Drawing.Color.Black;
            this.btn_1.Location = new System.Drawing.Point(297, 66);
            this.btn_1.Name = "btn_1";
            this.btn_1.Size = new System.Drawing.Size(23, 24);
            this.btn_1.TabIndex = 5;
            this.btn_1.UseVisualStyleBackColor = false;
            this.btn_1.Click += new System.EventHandler(this.btn_1_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.ForeColor = System.Drawing.Color.Black;
            this.label2.Location = new System.Drawing.Point(7, 38);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(56, 19);
            this.label2.TabIndex = 6;
            this.label2.Text = "Key \'0\'";
            // 
            // btn_0
            // 
            this.btn_0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_0.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_0.ForeColor = System.Drawing.Color.Black;
            this.btn_0.Location = new System.Drawing.Point(297, 37);
            this.btn_0.Name = "btn_0";
            this.btn_0.Size = new System.Drawing.Size(23, 24);
            this.btn_0.TabIndex = 5;
            this.btn_0.UseVisualStyleBackColor = false;
            this.btn_0.Click += new System.EventHandler(this.btn_0_Click);
            // 
            // timer1
            // 
            this.timer1.Interval = 200;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick);
            // 
            // groupBox4
            // 
            this.groupBox4.Controls.Add(this.btn_ptp9);
            this.groupBox4.Controls.Add(this.btn_ptp8);
            this.groupBox4.Controls.Add(this.btn_ptp7);
            this.groupBox4.Controls.Add(this.btn_ptp6);
            this.groupBox4.Controls.Add(this.btn_ptp5);
            this.groupBox4.Controls.Add(this.btn_ptp4);
            this.groupBox4.Controls.Add(this.btn_ptp3);
            this.groupBox4.Controls.Add(this.btn_ptp2);
            this.groupBox4.Controls.Add(this.btn_ptp1);
            this.groupBox4.Controls.Add(this.btn_ptp0);
            this.groupBox4.Font = new System.Drawing.Font("微软雅黑", 10.5F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.groupBox4.ForeColor = System.Drawing.Color.Cyan;
            this.groupBox4.Location = new System.Drawing.Point(385, 371);
            this.groupBox4.Name = "groupBox4";
            this.groupBox4.Size = new System.Drawing.Size(336, 80);
            this.groupBox4.TabIndex = 18;
            this.groupBox4.TabStop = false;
            this.groupBox4.Text = "PTP Operation";
            // 
            // btn_ptp9
            // 
            this.btn_ptp9.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp9.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp9.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp9.Location = new System.Drawing.Point(286, 33);
            this.btn_ptp9.Name = "btn_ptp9";
            this.btn_ptp9.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp9.TabIndex = 18;
            this.btn_ptp9.Text = "9";
            this.btn_ptp9.UseVisualStyleBackColor = false;
            this.btn_ptp9.Click += new System.EventHandler(this.btn_ptp9_Click);
            // 
            // btn_ptp8
            // 
            this.btn_ptp8.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp8.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp8.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp8.Location = new System.Drawing.Point(257, 33);
            this.btn_ptp8.Name = "btn_ptp8";
            this.btn_ptp8.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp8.TabIndex = 17;
            this.btn_ptp8.Text = "8";
            this.btn_ptp8.UseVisualStyleBackColor = false;
            this.btn_ptp8.Click += new System.EventHandler(this.btn_ptp8_Click);
            // 
            // btn_ptp7
            // 
            this.btn_ptp7.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp7.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp7.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp7.Location = new System.Drawing.Point(228, 33);
            this.btn_ptp7.Name = "btn_ptp7";
            this.btn_ptp7.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp7.TabIndex = 16;
            this.btn_ptp7.Text = "7";
            this.btn_ptp7.UseVisualStyleBackColor = false;
            this.btn_ptp7.Click += new System.EventHandler(this.btn_ptp7_Click);
            // 
            // btn_ptp6
            // 
            this.btn_ptp6.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp6.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp6.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp6.Location = new System.Drawing.Point(199, 33);
            this.btn_ptp6.Name = "btn_ptp6";
            this.btn_ptp6.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp6.TabIndex = 15;
            this.btn_ptp6.Text = "6";
            this.btn_ptp6.UseVisualStyleBackColor = false;
            this.btn_ptp6.Click += new System.EventHandler(this.btn_ptp6_Click);
            // 
            // btn_ptp5
            // 
            this.btn_ptp5.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp5.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp5.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp5.Location = new System.Drawing.Point(170, 33);
            this.btn_ptp5.Name = "btn_ptp5";
            this.btn_ptp5.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp5.TabIndex = 14;
            this.btn_ptp5.Text = "5";
            this.btn_ptp5.UseVisualStyleBackColor = false;
            this.btn_ptp5.Click += new System.EventHandler(this.btn_ptp5_Click);
            // 
            // btn_ptp4
            // 
            this.btn_ptp4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp4.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp4.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp4.Location = new System.Drawing.Point(141, 33);
            this.btn_ptp4.Name = "btn_ptp4";
            this.btn_ptp4.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp4.TabIndex = 13;
            this.btn_ptp4.Text = "4";
            this.btn_ptp4.UseVisualStyleBackColor = false;
            this.btn_ptp4.Click += new System.EventHandler(this.btn_ptp4_Click);
            // 
            // btn_ptp3
            // 
            this.btn_ptp3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp3.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp3.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp3.Location = new System.Drawing.Point(112, 33);
            this.btn_ptp3.Name = "btn_ptp3";
            this.btn_ptp3.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp3.TabIndex = 12;
            this.btn_ptp3.Text = "3";
            this.btn_ptp3.UseVisualStyleBackColor = false;
            this.btn_ptp3.Click += new System.EventHandler(this.btn_ptp3_Click);
            // 
            // btn_ptp2
            // 
            this.btn_ptp2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp2.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp2.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp2.Location = new System.Drawing.Point(83, 33);
            this.btn_ptp2.Name = "btn_ptp2";
            this.btn_ptp2.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp2.TabIndex = 11;
            this.btn_ptp2.Text = "2";
            this.btn_ptp2.UseVisualStyleBackColor = false;
            this.btn_ptp2.Click += new System.EventHandler(this.btn_ptp2_Click);
            // 
            // btn_ptp1
            // 
            this.btn_ptp1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp1.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp1.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp1.Location = new System.Drawing.Point(54, 33);
            this.btn_ptp1.Name = "btn_ptp1";
            this.btn_ptp1.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp1.TabIndex = 10;
            this.btn_ptp1.Text = "1";
            this.btn_ptp1.UseVisualStyleBackColor = false;
            this.btn_ptp1.Click += new System.EventHandler(this.btn_ptp1_Click);
            // 
            // btn_ptp0
            // 
            this.btn_ptp0.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0)))));
            this.btn_ptp0.Font = new System.Drawing.Font("微软雅黑", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.btn_ptp0.ForeColor = System.Drawing.Color.Black;
            this.btn_ptp0.Location = new System.Drawing.Point(25, 33);
            this.btn_ptp0.Name = "btn_ptp0";
            this.btn_ptp0.Size = new System.Drawing.Size(30, 30);
            this.btn_ptp0.TabIndex = 9;
            this.btn_ptp0.Text = "0";
            this.btn_ptp0.UseVisualStyleBackColor = false;
            this.btn_ptp0.Click += new System.EventHandler(this.btn_ptp0_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(26, 21);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(229, 52);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 20;
            this.pictureBox1.TabStop = false;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("微软雅黑", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(134)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(261, 33);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(442, 26);
            this.label1.TabIndex = 19;
            this.label1.Text = "Advantech MAS Controller-KeyBoard routine";
            // 
            // KeyBoardTest02
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Teal;
            this.ClientSize = new System.Drawing.Size(740, 507);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox4);
            this.Controls.Add(this.groupBox3);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.btn_return);
            this.Controls.Add(this.label18);
            this.Controls.Add(this.groupBox1);
            this.Name = "KeyBoardTest02";
            this.Text = "示教界面";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.KeyBoardTest02_FormClosing);
            this.Load += new System.EventHandler(this.Form2_Load);
            this.groupBox3.ResumeLayout(false);
            this.groupBox3.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txt_z_dpos;
        private System.Windows.Forms.TextBox txt_x_dpos;
        private System.Windows.Forms.GroupBox groupBox3;
        private System.Windows.Forms.Button btn_jog_neg;
        private System.Windows.Forms.Button btn_jog_pos;
        private System.Windows.Forms.TextBox txt_9_z;
        private System.Windows.Forms.TextBox txt_8_z;
        private System.Windows.Forms.TextBox txt_7_z;
        private System.Windows.Forms.TextBox txt_6_z;
        private System.Windows.Forms.TextBox txt_5_z;
        private System.Windows.Forms.TextBox txt_4_z;
        private System.Windows.Forms.TextBox txt_3_z;
        private System.Windows.Forms.TextBox txt_2_z;
        private System.Windows.Forms.TextBox txt_1_z;
        private System.Windows.Forms.TextBox txt_0_z;
        private System.Windows.Forms.TextBox txt_9_y;
        private System.Windows.Forms.TextBox txt_8_y;
        private System.Windows.Forms.TextBox txt_6_y;
        private System.Windows.Forms.TextBox txt_5_y;
        private System.Windows.Forms.TextBox txt_y_dpos;
        private System.Windows.Forms.TextBox txt_7_y;
        private System.Windows.Forms.TextBox txt_4_y;
        private System.Windows.Forms.TextBox txt_3_y;
        private System.Windows.Forms.TextBox txt_2_y;
        private System.Windows.Forms.TextBox txt_1_y;
        private System.Windows.Forms.TextBox txt_0_y;
        private System.Windows.Forms.TextBox txt_9_x;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label13;
        private System.Windows.Forms.Label label14;
        private System.Windows.Forms.TextBox txt_8_x;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.Label label12;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.TextBox txt_7_x;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.TextBox txt_6_x;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.TextBox txt_5_x;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox txt_4_x;
        private System.Windows.Forms.Button btn_9;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Button btn_return;
        private System.Windows.Forms.Label label18;
        private System.Windows.Forms.Button btn_8;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox txt_3_x;
        private System.Windows.Forms.Button btn_7;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Button btn_6;
        private System.Windows.Forms.TextBox txt_2_x;
        private System.Windows.Forms.Button btn_5;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btn_4;
        private System.Windows.Forms.TextBox txt_1_x;
        private System.Windows.Forms.Button btn_3;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Button btn_2;
        private System.Windows.Forms.TextBox txt_0_x;
        private System.Windows.Forms.Button btn_1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Button btn_0;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.RadioButton radioButton3;
        private System.Windows.Forms.RadioButton radioButton2;
        private System.Windows.Forms.RadioButton radioButton1;
        private System.Windows.Forms.TextBox txt_state;
        private System.Windows.Forms.GroupBox groupBox4;
        private System.Windows.Forms.Button btn_ptp9;
        private System.Windows.Forms.Button btn_ptp8;
        private System.Windows.Forms.Button btn_ptp7;
        private System.Windows.Forms.Button btn_ptp6;
        private System.Windows.Forms.Button btn_ptp5;
        private System.Windows.Forms.Button btn_ptp4;
        private System.Windows.Forms.Button btn_ptp3;
        private System.Windows.Forms.Button btn_ptp2;
        private System.Windows.Forms.Button btn_ptp1;
        private System.Windows.Forms.Button btn_ptp0;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label16;
    }
}
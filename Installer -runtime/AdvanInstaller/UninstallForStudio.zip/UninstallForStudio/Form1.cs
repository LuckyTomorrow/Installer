﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Diagnostics;
using System.Runtime.InteropServices;
using Microsoft.Win32;

namespace StudioUninst
{
    public partial class Form1 : Form
    {
        public static string StartMenu = "C:/ProgramData/Microsoft/Windows/Start Menu/Programs/";
        public static string StudioPath = "C:/Advantech/";
        public Form1()
        {
            InitializeComponent();
        }

        private void btn_cancle_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void btn_sure_Click(object sender, EventArgs e)
        {
            //清除注册表
            RegistryKey hkml = Registry.LocalMachine;
            RegistryKey software = hkml.OpenSubKey(@"SYSTEM\CurrentControlSet\Control\Lsa\FipsAlgorithmPolicy", true);
            software = hkml.OpenSubKey(@"SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\", true);
            if (software.OpenSubKey("Motion Studio") != null)
            {
                software.DeleteSubKey("Motion Studio");
            }

            #region 删除安装时移动的解压缩dll
            string dlltemp = Environment.GetFolderPath(Environment.SpecialFolder.CommonTemplates) + @"\ICSharpCode.SharpZipLib.dll";
            if (System.IO.File.Exists(dlltemp))
            {
                System.IO.File.Delete(dlltemp);
            }
            #endregion

            //先删除开始菜单快捷键
            string path = StartMenu + "Advantech Automation/Motion_Studio";
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
            }

            //删除Motion Studio.exe 桌面快捷键
            path = Environment.GetFolderPath(Environment.SpecialFolder.Desktop) + "//Motion Studio.lnk";
            if (File.Exists(path))
            {
                File.Delete(path);
            }

            //删除除Motion Studio外的对应的文件夹
            if (Directory.Exists(StudioPath))
            {
                string[] totalPath = {"Libraries", "Example", "Documents" };
                for (int i = 0; i < totalPath.Length; i++)
                {
                    string ss = StudioPath + totalPath[i];
                    if (Directory.Exists(ss))
                    {
                        Directory.Delete(ss, true);
                    }
                }
            }
            //删除除Motion Studio文件夹下的文件夹
            if (Directory.Exists(StudioPath + "Motion Studio"))
            {
                if (Directory.GetDirectories(StudioPath + "Motion Studio") != null)
                {
                    string[] cc = Directory.GetDirectories(StudioPath + "Motion Studio");
                    for (int i = 0; i < cc.Length; i++)
                    {
                        Directory.Delete(cc[i], true);
                    }
                }

                //删除除Motion Studio文件夹下的文件，如果为程序本身，先跳过
                if (Directory.GetFiles(StudioPath + "Motion Studio") != null)
                {
                    string[] cc = Directory.GetFiles(StudioPath + "Motion Studio");
                    for (int i = 0; i < cc.Length; i++)
                    {
                        if (cc[i].Contains("StudioUninst.exe"))
                        {
                            continue;
                        }

                        File.Delete(cc[i]);
                    }

                    //删除程序本身
                    DeleteItselfByCMD();
                }
            }

            this.Close();
        }

        /// <summary>
        /// 删除程序自身（本文地址：http://www.cnblogs.com/Interkey/p/DeleteItself.html）
        /// </summary>
        private static void DeleteItselfByCMD()
        {
            string vBatFile = @"C:\Advantech\Motion Studio\delete.bat";
            using (StreamWriter vStreamWriter = new StreamWriter(vBatFile, false, Encoding.Default))

            {
                vStreamWriter.Write(string.Format(

                   ":del\r\n" +
                    " del \"{0}\"\r\n" +
                    "if exist \"{0}\" goto del\r\n" + //如果存在uninstall.exe和uninstall.exe的上层目录

                     ":del2\r\n" +
                     "cd..& rd /s /q \"%~dp0\"" +
                     "if exist \"{1}\" goto del2\r\n" +
                    //删除上面之后，删除bat文件自身              
                    "del %0\r\n" , @"C:\Advantech\Motion Studio\StudioUninst.exe", @"C:\Advantech\Motion Studio")
                );
            }
            
            WinExec(vBatFile, 0);

        }

        private void Form1_Load(object sender, EventArgs e)
        {
           
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
        }

        [DllImport("kernel32.dll")]
        public static extern uint WinExec(string lpCmdLine, uint uCmdShow);
    }
}
